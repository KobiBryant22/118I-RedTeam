import streamlit as st
import pandas as pd
from datetime import datetime
from openai import OpenAI

# --- Set Page Settings ---
st.set_page_config(page_title="City Connect", layout="centered")

# --- Title ---
st.markdown("# 🌟 City Connect")

# --- Custom CSS Styling ---
st.markdown(
    """
    <style>
    /* General background */
    body, .stApp {
        background-color: #f8f5f2;
        color: #2e7d32;
        font-family: 'Poppins', sans-serif;
    }

    /* Buttons */
    .stButton>button {
        background-color: #81c784;
        color: #2e7d32;
        border-radius: 12px;
        padding: 14px 28px;
        font-size: 16px;
        font-weight: bold;
    }
    .stButton>button:hover {
        background-color: #66bb6a;
        color: #1b5e20;
    }

    /* Inputs, Dropdowns, Textareas */
    .stTextInput input,
    .stDateInput input,
    .stTextArea textarea {
        background-color: #e8f5e9;
        color: #1b5e20;
        border-radius: 10px;
        padding: 16px;
        font-size: 16px;
    }

/* Dropdown menu itself */
    div[data-baseweb="select"] > div {
        background-color: #e8f5e9 !important;
        color: #1b5e20 !important;
        border-radius: 10px;
        padding: 16px;
        font-size: 16px;
    }
    
    /* Dropdown menu options */
    div[data-baseweb="menu"] {
        background-color: #e8f5e9;
        color: #1b5e20;
        font-size: 16px;
    }
    
    /* Selected dropdown text */
    .stSelectbox>div>div>div {
        background-color: #e8f5e9 !important;
        color: #1b5e20 !important;
        font-size: 16px;
    }

    div[data-baseweb="option"] {
        background-color: #e8f5e9;
        color: #1b5e20;
        font-size: 16px;
    }
    div[data-baseweb="option"]:hover {
        background-color: #c8e6c9;
        color: #1b5e20;
    }

    /* Placeholder text */
    .css-1wa3eu0-placeholder {
        color: #4caf50;
        opacity: 0.7;
        font-size: 16px;
    }

    /* Make TextArea bigger */
    .stTextArea textarea {
        min-height: 180px;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# --- Load Data ---
schedule_df = pd.read_csv("Park_schedule.csv")
amenities_df = pd.read_csv("Park_amenities.csv")
log_df = pd.read_csv("reservations_log.csv")
locations_df = pd.read_csv("Park_location.csv")

# Remove stray header rows if duplicated
schedule_df = schedule_df[schedule_df["date"] != "date"]

# Convert date column to datetime format
schedule_df["date"] = pd.to_datetime(schedule_df["date"], errors='coerce')

# --- Sidebar Navigation ---
st.sidebar.title("📋 Navigation")
page = st.sidebar.radio(
    "Go to:",
    ["Chatbot Assistant", "Reservation", "Park Data Insights", "Report an Issue"]
)

# --- Pages ---
if page == "Chatbot Assistant":
    st.header("💬 Chatbot Assistant")

    from datetime import datetime
    import pydeck as pdk

    # OpenAI API client
    client = OpenAI(api_key="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")

    # --- Initialize Session State ---
    if 'reservation_data' not in st.session_state:
        st.session_state.reservation_data = {
            "name": "",
            "email": "",
            "phone": "",
            "park": "",
            "date": "",
            "time_slot": ""
        }
    if 'messages' not in st.session_state:
        st.session_state.messages = []
    if 'booking_progress' not in st.session_state:
        st.session_state.booking_progress = None

    # --- Load Data ---
    amenities_df = pd.read_csv("Park_amenities.csv")
    locations_df = pd.read_csv("Park_location.csv")
    schedule_df = pd.read_csv("Park_schedule.csv")
    schedule_df["date"] = pd.to_datetime(schedule_df["date"], errors="coerce")

    # --- Display conversation history ---
    for msg in st.session_state.messages:
        if msg["role"] == "user":
            with st.chat_message("user"):
                st.write(msg["content"])
        elif msg["role"] == "assistant":
            with st.chat_message("assistant"):
                if "text" in msg:
                    st.write(msg["text"])
                if "map_df" in msg:
                    map_layer = pdk.Layer(
                        "ScatterplotLayer",
                        data=msg["map_df"],
                        get_position='[lon, lat]',
                        get_color='[255, 0, 0, 160]',
                        get_radius=100,
                        pickable=True,
                    )
                    view_state = pdk.ViewState(
                        latitude=msg["map_df"]["lat"].mean(),
                        longitude=msg["map_df"]["lon"].mean(),
                        zoom=11,
                        pitch=0,
                    )
                    tooltip = {
                        "html": "<b>🏞️ Park:</b> {park_name}",
                        "style": {
                            "backgroundColor": "white",
                            "color": "black",
                            "fontSize": "14px"
                        }
                    }
                    st.pydeck_chart(pdk.Deck(
                        map_style="mapbox://styles/mapbox/light-v9",
                        initial_view_state=view_state,
                        layers=[map_layer],
                        tooltip=tooltip
                    ))

# --- Chat Input ---
user_input = st.chat_input("Ask me about parks, amenities, or start your reservation!")

if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})

    user_message_lower = user_input.lower()

    # --- Start reservation if triggered ---
    if any(word in user_message_lower for word in ["reservation", "book", "schedule", "reserve"]) and st.session_state.booking_progress is None:
        st.session_state.booking_progress = "name"
        st.session_state.messages.append({"role": "assistant", "text": "Sure! Let's make a reservation. What's your full name?"})
        st.rerun()

    # --- Handle active reservation booking ---
    if st.session_state.booking_progress:
        current_step = st.session_state.booking_progress

        # Handle availability questions at any step
        if "available" in user_message_lower and st.session_state.reservation_data["park"]:
            if current_step in ["date", "time_slot"]:
                if current_step == "date":
                    available_dates = schedule_df[
                        (schedule_df["park_name"].str.lower() == st.session_state.reservation_data["park"].lower()) &
                        (schedule_df["status"] == "available")
                    ]["date"].dt.date.unique()
                    if len(available_dates) > 0:
                        dates_text = ", ".join([str(d) for d in available_dates])
                        st.session_state.messages.append({"role": "assistant", "text": f"🗓️ Available dates for {st.session_state.reservation_data['park']}: {dates_text}. Please pick one."})
                    else:
                        st.session_state.messages.append({"role": "assistant", "text": "😢 No available dates for that park."})
                elif current_step == "time_slot":
                    selected_date = st.session_state.reservation_data["date"]
                    available_slots = schedule_df[
                        (schedule_df["park_name"].str.lower() == st.session_state.reservation_data["park"].lower()) &
                        (schedule_df["date"].dt.date == datetime.strptime(selected_date, "%Y-%m-%d").date()) &
                        (schedule_df["status"] == "available")
                    ]["time_slot"].unique()
                    if len(available_slots) > 0:
                        slots_text = ", ".join(available_slots)
                        st.session_state.messages.append({"role": "assistant", "text": f"⏰ Available time slots for {st.session_state.reservation_data['park']} on {selected_date}: {slots_text}. Please pick one."})
                    else:
                        st.session_state.messages.append({"role": "assistant", "text": "😢 No available time slots for that date."})
                st.rerun()

        else:
            # Regular booking steps
            if current_step == "name":
                st.session_state.reservation_data["name"] = user_input
                st.session_state.booking_progress = "email"
                st.session_state.messages.append({"role": "assistant", "text": "Great! What's your email address?"})
                st.rerun()

            elif current_step == "email":
                if "@" in user_input and "." in user_input:
                    st.session_state.reservation_data["email"] = user_input
                    st.session_state.booking_progress = "phone"
                    st.session_state.messages.append({"role": "assistant", "text": "Thanks! Could you also provide your phone number?"})
                else:
                    st.session_state.messages.append({"role": "assistant", "text": "⚠️ Please enter a valid email address."})
                st.rerun()

            elif current_step == "phone":
                if user_input.isdigit() and len(user_input) >= 10:
                    st.session_state.reservation_data["phone"] = user_input
                    st.session_state.booking_progress = "park"
                    st.session_state.messages.append({"role": "assistant", "text": "Which park would you like to reserve?"})
                else:
                    st.session_state.messages.append({"role": "assistant", "text": "⚠️ Please enter a valid 10-digit phone number."})
                st.rerun()

            elif current_step == "park":
                st.session_state.reservation_data["park"] = user_input
                st.session_state.booking_progress = "date"
                st.session_state.messages.append({"role": "assistant", "text": "What date would you like to book? (Format: YYYY-MM-DD)"})
                st.rerun()

            elif current_step == "date":
                try:
                    datetime.strptime(user_input, "%Y-%m-%d")
                    st.session_state.reservation_data["date"] = user_input
                    st.session_state.booking_progress = "time_slot"
                    st.session_state.messages.append({"role": "assistant", "text": "Lastly, what time slot would you like?"})
                except ValueError:
                    st.session_state.messages.append({"role": "assistant", "text": "⚠️ Please use the format YYYY-MM-DD."})
                st.rerun()

            elif current_step == "time_slot":
                st.session_state.reservation_data["time_slot"] = user_input
                st.session_state.booking_progress = None

                # Save reservation
                new_booking = {
                    "name": st.session_state.reservation_data['name'],
                    "email": st.session_state.reservation_data['email'],
                    "phone": st.session_state.reservation_data['phone'],
                    "park_name": st.session_state.reservation_data['park'],
                    "date": st.session_state.reservation_data['date'],
                    "time_slot": st.session_state.reservation_data['time_slot']
                }
                log_df = pd.concat([log_df, pd.DataFrame([new_booking])], ignore_index=True)
                log_df.to_csv("reservations_log.csv", index=False)

                st.session_state.messages.append({
                    "role": "assistant",
                    "text": f"✅ Your reservation at {st.session_state.reservation_data['park']} is confirmed! 🚚 We'll send you an email soon."
                })

                # Reset after booking
                st.session_state.reservation_data = {key: "" for key in st.session_state.reservation_data}
                st.rerun()

elif page == "Reservation":
    st.header("👨‍💼 Your Contact Information")
    name = st.text_input("Full Name")
    email = st.text_input("Email Address")
    phone = st.text_input("Phone Number")

    st.header("📍 Reservation Details")
    parks = schedule_df["park_name"].unique()
    selected_park = st.selectbox("Choose a park:", parks)

    available_dates = schedule_df[
        (schedule_df["park_name"] == selected_park) & (schedule_df["status"] == "available")
    ]["date"].dt.date.unique()

    selected_date = st.date_input("Choose a date:", min_value=datetime.now().date())

    available_slots = schedule_df[
        (schedule_df["park_name"] == selected_park) &
        (schedule_df["date"].dt.date == selected_date) &
        (schedule_df["status"] == "available")
    ]["time_slot"].unique()

    selected_slot = st.selectbox("Choose a time slot:", available_slots if len(available_slots) > 0 else ["No options available"])

    if st.button("✅ Book Now") and selected_slot != "No options available":
        new_booking = {
            "name": name,
            "email": email,
            "phone": phone,
            "park_name": selected_park,
            "date": selected_date.strftime("%Y-%m-%d"),
            "time_slot": selected_slot
        }
        log_df = pd.concat([log_df, pd.DataFrame([new_booking])], ignore_index=True)
        log_df.to_csv("reservations_log.csv", index=False)

        # Update schedule
        schedule_df.loc[
            (schedule_df["park_name"] == selected_park) &
            (schedule_df["date"].dt.date == selected_date) &
            (schedule_df["time_slot"] == selected_slot),
            "status"
        ] = "booked"
        schedule_df.to_csv("Park_schedule.csv", index=False)

        st.success(f"Reservation confirmed for {selected_park} on {selected_date} at {selected_slot}!")
        st.info("You will receive a confirmation email shortly (mock only).")

elif page == "Park Data Insights":
    st.header("📊 Park Data Insights & Filter")
    st.subheader("🔍 Filter Parks by Amenities")

    # Load the amenities info
    amenities_df = pd.read_csv("Park_amenities.csv")

    # Load the park location info
    locations_df = pd.read_csv("Park_location.csv")  # Should have Park, lat, lon columns

    # Checkbox filters
    filter_options = {
        "BBQ": st.checkbox("Must have BBQ"),
        "Basketball Court": st.checkbox("Must have Basketball Court"),
        "Playground": st.checkbox("Must have Playground"),
        "Restroom": st.checkbox("Must have Restroom"),
        "Tennis Courts": st.checkbox("Must have Tennis Courts"),
        "Volleyball": st.checkbox("Must have Volleyball"),
        "Skate Park": st.checkbox("Must have Skate Park"),
        "Soccer Field": st.checkbox("Must have Soccer Field"),
        "Pickleball": st.checkbox("Must have Pickleball")
    }

    # Filter amenities based on selected options
    filtered_df = amenities_df.copy()
    for amenity, required in filter_options.items():
        if required and amenity in filtered_df.columns:
            filtered_df = filtered_df[filtered_df[amenity] == True]


    # --- Map section ---
    st.subheader('🗺️ Maps', divider='grey')

    # Merge filtered amenities with locations
    merged_df = pd.merge(
    filtered_df,
    locations_df,
    left_on="Park",
    right_on="Park Name",
    how="inner"
)

    # Check if there are parks to display
    if not merged_df.empty:
        map_df = merged_df[["Latitude", "Longitude"]]
        map_df.columns = ["lat", "lon"]


        import pydeck as pdk

        layer = pdk.Layer(
            "ScatterplotLayer",
            data=map_df,
            get_position='[lon, lat]',
            get_color='[255, 0, 0, 160]',  # Red color
            get_radius=100,
            pickable=True,
        )

        view_state = pdk.ViewState(
            latitude=map_df["lat"].mean(),
            longitude=map_df["lon"].mean(),
            zoom=11,
            pitch=0,
        )

        st.pydeck_chart(pdk.Deck(
            map_style="mapbox://styles/mapbox/light-v9",
            initial_view_state=view_state,
            layers=[layer],
        ))
    else:
        st.warning("No parks match the selected filters.")


elif page == "Report an Issue":
    st.header("🛠️ Park Issue Reporting")
    issue_description = st.text_area("Describe the issue you're experiencing:")
    issue_type = st.selectbox("Issue type:", ["Litter", "Damaged Equipment", "Graffiti", "Other"])
    parks = schedule_df["park_name"].unique()
    issue_park = st.selectbox("Which park?", parks)

    if st.button("🛠️ Submit Report"):
        st.success("Your issue has been submitted. Thank you for helping improve our parks!")